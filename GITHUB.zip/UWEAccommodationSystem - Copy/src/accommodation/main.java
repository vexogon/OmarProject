/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package accommodation;


public class main {

  public static void main(String[] args) {
      uweAccommodationTeam uweAccommTeam = uweAccommodationTeam.getInstance();
      System.out.println("END");
      
      
/*
    Student student = new Student(1, "Omar Sherif", "0777-807-1503");

HallManager manager = new HallManager("Jane Smith");
AccommodationType EnsuiteType = new AccommodationType("Ensuite", "One bed", 500f);
Accommodation accommodation = new Accommodation(906, EnsuiteType);
AccommodationStatus accommodationStatus = new AccommodationStatus(true, false);
CleaningStatus cleaningStatus = new CleaningStatus(true, false, false);
RentalAgreement agreement = new RentalAgreement(1234, student);
accommodation.createRentalAgreement(agreement);
Hall hall = new Hall("Purdown View Hall");
hall.addAccommodation(accommodation);

uweAccommodationTeam team = new uweAccommodationTeam();

team.addHall(hall);

    // Print details
System.out.println("Student: " + student.getName());
System.out.println("Student mobile number: " + student.getMobileNumber());
System.out.println("Hall: " + hall.getName());
System.out.println("Accommodation: " + accommodation.getRoomNumber());
System.out.println("Accommodation type: " + accommodation.getType().getName());
System.out.println("Accommodation status: " + accommodationStatus.getStatus());
System.out.println("Cleaning status: " + cleaningStatus.getCleaningStatus());
System.out.println("Agreement: " + agreement.getLeaseNumber());
*/

  }

}
